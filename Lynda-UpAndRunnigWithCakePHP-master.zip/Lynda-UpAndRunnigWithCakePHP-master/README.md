Video tutorial
Lynda - Up and runnig with CakePHP
