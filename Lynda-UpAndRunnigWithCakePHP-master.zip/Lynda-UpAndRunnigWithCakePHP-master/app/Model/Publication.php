<?php

App::uses('AppModel', 'Model');

/**
 * Publication Model
 *
 */
class Publication extends AppModel {

    /**
     * Primary key field
     *
     * @var string
     */
    public $primaryKey = 'publication_id';

    /**
     * Display field
     *
     * @var string
     */
    public $displayField = 'publication_name';

    /**
     * Validation rules
     *
     * @var array
     */
    public $validate = array(
        'publication_id' => array(
            'blank' => array(
                'rule' => 'blank',
                'on' => 'create'
            ),
        ),
        'publication_name' => array(
            'notEmpty' => array(
                'rule' => array('notEmpty'),
                'message' => 'The publication name must not be empty!'
            ),
            'words' => array(
                'rule' => array('custom', '/([\w.-]+ )+[\w+.-]/'),
                'message' => 'Your publication name can only contain letters, numberes and spaces.'
            ),
            'maxLength' => array(
                'rule' => array('maxLength', 100), // The length is in bytes
                'message' => 'The publication name must not be longer than 100 symbols.'
            ),
            'is_unique' => array(
                'rule'=>'isUnique',
                'message'=>'The publication name already exist.'
            )
        ),
    );
    
 /**
 * hasMany associations
 *
 * @var array
 */
	public $hasMany = array(
		'PublicationIssues' => array(
			'className' => 'Issue',
			'foreignKey' => 'issue_publication_id',
		)
	);

}
